---
id: R0f13fa7b46d35adb
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# Ritchie, H. Sector by sector: where do global greenhouse gas emissions come from? Our World in Data https://ourworldindata.org/ghg-emissions-by-sector (2020).

