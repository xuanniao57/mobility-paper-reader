---
id: R0e201ab2d5bbba85
year: 2020
journal: "Sci. Adv."
tags: [引用网络, "年代/6—10年"]
---

# Oliver, N. et al. Mobile phone data for informing public health actions across the COVID-19 pandemic life cycle. Sci. Adv. 6, eabc0764 (2020).

[DOI](https://doi.org/10.1126/sciadv.abc0764)

