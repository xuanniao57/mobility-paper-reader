---
id: R13c7eaf7fc0c6abf
year: 2023
journal: "Transportation Research Part D: Transport and Environment"
tags: [引用网络, "年代/0—5年"]
---

# Delineating race-specific driving patterns for identifying racial segregation

[DOI](https://doi.org/10.1016/j.trd.2023.103769)

