---
id: R11bce1408ead3eff
year: 2000
journal: "Int. J. Popul. Geogr."
tags: [引用网络, "年代/20年以上"]
---

# An evaluation of the combinatorial optimisation approach to the creation of synthetic microdata

[DOI](https://doi.org/10.1002/1099-1220(200009/10)6:5<349::aid-ijpg196>3.0.co;2-5)

