---
id: R073cc7cf6fbd5d0b
year: 2021
journal: "Transportation Research Part C: Emerging Technologies"
tags: [引用网络, "年代/0—5年"]
---

# On the inefficiency of ride-sourcing services towards urban congestion

[DOI](https://doi.org/10.1016/j.trc.2020.102890)

