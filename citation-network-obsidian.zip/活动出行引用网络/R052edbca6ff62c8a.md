---
id: R052edbca6ff62c8a
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# T. Kojima S. S. Gu M. Reid Y. Matsuo Y. Iwasawa Large language models are zero-shot reasoners. arXiv:2205.11916 (2022).

