---
id: R06ca58cf770d0ece
year: 1996
journal: "Transportation"
tags: [引用网络, "年代/20年以上"]
---

# Travel demand model system for the information era

[DOI](https://doi.org/10.1007/bf00165704)

