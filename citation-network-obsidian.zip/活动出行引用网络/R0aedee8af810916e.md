---
id: R0aedee8af810916e
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1109/snpd.2017.8023884

[DOI](https://doi.org/10.1109/snpd.2017.8023884)

