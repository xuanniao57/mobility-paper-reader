---
id: R0f45db04f4fef58a
year: 2017
journal: "ISPRS International Journal of Geo-Information"
tags: [引用网络, "年代/6—10年"]
---

# Understanding the representativeness of mobile phone location data in characterizing human mobility indicators

