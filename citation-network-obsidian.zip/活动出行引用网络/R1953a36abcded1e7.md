---
id: R1953a36abcded1e7
year: 2009
journal: "Proceedings of the 17th ACM SIGSPATIAL International Conference on Advances in Geographic Information Systems"
tags: [引用网络, "年代/11—20年"]
---

# Hidden Markov map matching through noise and sparseness

[DOI](https://doi.org/10.1145/1653771.1653818)

