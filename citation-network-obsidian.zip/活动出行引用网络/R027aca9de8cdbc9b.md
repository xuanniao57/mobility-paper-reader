---
id: R027aca9de8cdbc9b
year: 1997
journal: "期刊/来源待解析"
tags: [引用网络, "年代/20年以上"]
---

# ; ; ; 1997. Asset Pricing under Endogenous Expectations in an Artificial Stock Market. In The Economy as a Complex Evolving System II. ; ; eds. Menlo Park: Addison-Wesley.

