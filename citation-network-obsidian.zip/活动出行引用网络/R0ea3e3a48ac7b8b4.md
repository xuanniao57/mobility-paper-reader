---
id: R0ea3e3a48ac7b8b4
year: 2023
journal: "Transp. Res. Part C: Emerg. Technol."
tags: [引用网络, "年代/0—5年"]
---

# A data fusion approach for ride-sourcing demand estimation: A discrete choice model with sampling and endogeneity corrections

[DOI](https://doi.org/10.1016/j.trc.2023.104180)

