---
id: R13442df31dac5cae
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1073/pnas.0400054101

[DOI](https://doi.org/10.1073/pnas.0400054101)

