---
id: R0b8fadc9465cd5e5
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# Gunn, H.F., van der Hoorn, A.I.J.M., Daly, A.J., 1987. Long range country-wide travel demand forecasts from models of individual choice. In: Fifth International Conference on Travel Behaviour. 1987, Aiix-en Provence

