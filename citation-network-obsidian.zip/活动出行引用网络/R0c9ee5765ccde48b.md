---
id: R0c9ee5765ccde48b
year: 2015
journal: "2015 IEEE 31st International Conference on Data Engineering"
tags: [引用网络, "年代/11—20年"]
---

# Personalized route recommendation using big trajectory data

[DOI](https://doi.org/10.1109/icde.2015.7113313)

