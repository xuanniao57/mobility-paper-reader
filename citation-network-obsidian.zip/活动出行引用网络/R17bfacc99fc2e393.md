---
id: R17bfacc99fc2e393
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1038/nphys560

[DOI](https://doi.org/10.1038/nphys560)

