---
id: R0dd5b2bb0db24b26
year: 2007
journal: "Scandinavian Political Studies"
tags: [引用网络, "年代/11—20年"]
---

# E pluribus unum: diversity and community in the twenty-first century the 2006 Johan Skytte prize lecture

[DOI](https://doi.org/10.1111/j.1467-9477.2007.00176.x)

