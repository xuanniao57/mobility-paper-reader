---
id: R0cd56a340a9aca5c
year: 2020
journal: "EPJ Data Sci."
tags: [引用网络, "年代/6—10年"]
---

# Yabe, T., Zhang, Y. & Ukkusuri, S. V. Quantifying the economic impact of disasters on businesses using human mobility data: a bayesian causal inference approach. EPJ Data Sci. 9, 36 (2020).

[DOI](https://doi.org/10.1140/epjds/s13688-020-00255-6)

