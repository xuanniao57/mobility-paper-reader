---
id: R0e779ea5efbd1b02
year: 1996
journal: "Nature"
tags: [引用网络, "年代/20年以上"]
---

# 10.1038/379804a0

[DOI](https://doi.org/10.1038/379804a0)

