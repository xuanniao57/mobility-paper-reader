---
id: R05dcff0ac4a8df58
year: 2020
journal: "Tijdschrift voor Economische en Sociale Geografie"
tags: [引用网络, "年代/6—10年"]
---

# The Link Between Ethnic Segregation and Socio‐Economic Status: An Activity Space Approach

[DOI](https://doi.org/10.1111/tesg.12465)

