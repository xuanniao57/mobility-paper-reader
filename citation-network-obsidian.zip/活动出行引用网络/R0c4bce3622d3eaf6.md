---
id: R0c4bce3622d3eaf6
year: 2022
journal: "EPJ Data Sci."
tags: [引用网络, "年代/0—5年"]
---

# Salgado, A., Yuan, Z., Caridi, I. & González, M. C. Exposure to parks through the lens of urban mobility. EPJ Data Sci. 11, 42 (2022).

[DOI](https://doi.org/10.1140/epjds/s13688-022-00351-9)

