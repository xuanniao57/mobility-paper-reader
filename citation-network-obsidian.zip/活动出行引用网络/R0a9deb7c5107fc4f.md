---
id: R0a9deb7c5107fc4f
year: 2021
journal: "Sci. Rep."
tags: [引用网络, "年代/0—5年"]
---

# Verma, R., Yabe, T. & Ukkusuri, S. V. Spatiotemporal contact density explains the disparity of COVID-19 spread in urban neighborhoods. Sci. Rep. 11, 10952 (2021).

[DOI](https://doi.org/10.1038/s41598-021-90483-1)

