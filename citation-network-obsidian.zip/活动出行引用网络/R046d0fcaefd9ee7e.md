---
id: R046d0fcaefd9ee7e
year: 2021
journal: "EPJ Data Science"
tags: [引用网络, "年代/0—5年"]
---

# Evaluation of home detection algorithms on mobile phone data using individual-level ground truth

[DOI](https://doi.org/10.1140/epjds/s13688-021-00284-9)

