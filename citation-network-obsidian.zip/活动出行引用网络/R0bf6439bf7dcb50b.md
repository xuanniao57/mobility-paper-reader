---
id: R0bf6439bf7dcb50b
year: 2019
journal: "Transp. Res. Rec."
tags: [引用网络, "年代/6—10年"]
---

# Approximative network partitioning for MFDs from stationary sensor data

[DOI](https://doi.org/10.1177/0361198119843264)

