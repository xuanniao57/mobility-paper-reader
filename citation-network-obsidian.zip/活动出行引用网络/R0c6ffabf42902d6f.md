---
id: R0c6ffabf42902d6f
year: 2012
journal: "Studies in Regional Science"
tags: [引用网络, "年代/11—20年"]
---

# A spatial microsimulation approach to small area income estimation in Britain and Japan

[DOI](https://doi.org/10.2457/srs.42.163)

