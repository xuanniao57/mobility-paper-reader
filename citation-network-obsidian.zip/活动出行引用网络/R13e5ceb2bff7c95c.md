---
id: R13e5ceb2bff7c95c
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1049/itr2.12075

[DOI](https://doi.org/10.1049/itr2.12075)

