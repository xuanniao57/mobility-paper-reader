---
id: R0a1a9f33dda8e3e3
year: 2001
journal: "期刊/来源待解析"
tags: [引用网络, "年代/20年以上"]
---

# Anind K Dey. 2001. Understanding and using context. Personal and ubiquitous computing 5 (2001), 4–7.

