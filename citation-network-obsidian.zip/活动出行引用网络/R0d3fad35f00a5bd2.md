---
id: R0d3fad35f00a5bd2
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1371/journal.pcbi.1000609

[DOI](https://doi.org/10.1371/journal.pcbi.1000609)

