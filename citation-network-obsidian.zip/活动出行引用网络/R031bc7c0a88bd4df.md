---
id: R031bc7c0a88bd4df
year: 2020
journal: "期刊/来源待解析"
tags: [引用网络, "年代/6—10年"]
---

# Brown, T.B., 2020. Language models are few-shot learners. arXiv preprint arXiv:2005.14165.

