---
id: R17dc484c1eadd1fa
year: 2008
journal: "期刊/来源待解析"
tags: [引用网络, "年代/11—20年"]
---

# M Balmer, , Agent-based simulation of travel demand: Structure and computational performance of MATSim-T. 2nd TRB Conference on Innovations in Travel Modeling, Portland, Oregon (Eidgenössische Technische Hochschule Zürich, Zurich, 2008).

