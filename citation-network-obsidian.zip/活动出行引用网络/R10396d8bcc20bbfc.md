---
id: R10396d8bcc20bbfc
year: 2009
journal: "Transp. Res. Part A: Policy Pract."
tags: [引用网络, "年代/11—20年"]
---

# Eliasson, J., Hultkrantz, L., Nerhagen, L. & Rosqvist, L. S. The Stockholm congestion–charging trial 2006: overview of effects. Transp. Res. Part A: Policy Pract. 43, 240–250 (2009).

