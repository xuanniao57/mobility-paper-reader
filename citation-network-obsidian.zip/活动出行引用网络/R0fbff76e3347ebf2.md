---
id: R0fbff76e3347ebf2
year: 2020
journal: "International Journal of Sustainable Transportation"
tags: [引用网络, "年代/6—10年"]
---

# Pedestrian safety perception and urban street settings

[DOI](https://doi.org/10.1080/15568318.2019.1641577)

