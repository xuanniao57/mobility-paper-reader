---
id: R0be5cc0b60d3ecc4
year: 2024
journal: "Transp. Res. Part C: Emerg. Technol."
tags: [引用网络, "年代/0—5年"]
---

# Improving multi-modal transportation recommendation systems through contrastive De-biased heterogeneous graph neural networks

[DOI](https://doi.org/10.1016/j.trc.2024.104689)

