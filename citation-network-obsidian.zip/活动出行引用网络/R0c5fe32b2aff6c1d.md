---
id: R0c5fe32b2aff6c1d
year: 2021
journal: "Transp. B"
tags: [引用网络, "年代/0—5年"]
---

# Modelling multiple occurrences of activities during a day: an extension of the MDCEV model

