---
id: R18fbb07cca7339dd
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1111/j.1467-9787.1958.tb01366.x

[DOI](https://doi.org/10.1111/j.1467-9787.1958.tb01366.x)

