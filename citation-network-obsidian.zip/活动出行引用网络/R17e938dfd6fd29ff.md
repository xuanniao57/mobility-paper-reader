---
id: R17e938dfd6fd29ff
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# 10.1007/s10109-018-0273-6

[DOI](https://doi.org/10.1007/s10109-018-0273-6)

