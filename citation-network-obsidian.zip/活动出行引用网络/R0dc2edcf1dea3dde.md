---
id: R0dc2edcf1dea3dde
year: 2024
journal: "Computers, Environment and Urban Systems"
tags: [引用网络, "年代/0—5年"]
---

# Application of the local colocation quotient method in jobs-housing balance measurement based on mobile phone data: A case study of Nanjing city

