---
id: R105fbb65ba7f8ef9
year: 2024
journal: "Procedia Computer Science"
tags: [引用网络, "年代/0—5年"]
---

# Data-driven Agent-based Modeling: Experimenting with the Schelling’s Model

[DOI](https://doi.org/10.1016/j.procs.2024.06.028)

