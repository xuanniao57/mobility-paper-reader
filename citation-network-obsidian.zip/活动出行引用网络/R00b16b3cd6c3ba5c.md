---
id: R00b16b3cd6c3ba5c
year: 2010
journal: "Journal of Exposure Science & Environmental Epidemiology"
tags: [引用网络, "年代/11—20年"]
---

# The impact of daily mobility on exposure to traffic-related air pollution and health effect estimates

[DOI](https://doi.org/10.1038/jes.2010.14)

