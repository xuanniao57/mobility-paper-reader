---
id: R00fae8e417fc0dec
year: 1988
journal: "Transportation Science"
tags: [引用网络, "年代/20年以上"]
---

# Survey Paper—Time Window Constrained Routing and Scheduling Problems

[DOI](https://doi.org/10.1287/trsc.22.1.1)

