---
id: R0d7cbad92ceb938f
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# N. Fontana F. Pierri L. Aiello Nicer than humans: How do large language models behave in the prisoner’s dilemma? arXiv:2406.13605 (2024).

