---
id: R0e8b4bdad92f7b96
year: null
journal: "期刊/来源待解析"
tags: [引用网络, "年代/年份未知"]
---

# Brandes U. et al. 2006. Maximizing modularity is hard. arXiv Preprint Physics/0608255.

