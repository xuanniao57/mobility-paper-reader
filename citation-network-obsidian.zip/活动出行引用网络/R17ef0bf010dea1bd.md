---
id: R17ef0bf010dea1bd
year: 2020
journal: "SIGSpatial Spec."
tags: [引用网络, "年代/6—10年"]
---

# Gao, S., Rao, J., Kang, Y., Liang, Y. & Kruse, J. Mapping county-level mobility pattern changes in the United States in response to COVID-19. SIGSpatial Spec. 12, 16–26 (2020).

[DOI](https://doi.org/10.1145/3404820.3404824)

